﻿namespace SalesDW.API.Models
{
    public class TopProduct
    {
        public string ProductName { get; set; }
        public decimal Revenue { get; set; }
    }
}