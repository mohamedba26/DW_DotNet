﻿namespace SalesDW.API.Models
{
    public class TotalSalesByYear
    {
        public int YearNumber { get; set; }
        public decimal TotalSales { get; set; }
    }
}
