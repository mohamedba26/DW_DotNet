﻿namespace SalesDW.API.Models
{
    public class SalesByTerritory
    {
        public string TerritoryName { get; set; }
        public decimal TotalSales { get; set; }
    }
}