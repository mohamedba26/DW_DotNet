﻿namespace SalesDW.API.Models
{
    public class PurchasingByVendor
    {
        public string VendorName { get; set; }
        public decimal TotalPurchasing { get; set; }
    }
}