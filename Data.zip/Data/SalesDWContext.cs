﻿using Microsoft.EntityFrameworkCore;
using SalesDW.API.Models;

namespace SalesDW.API.Data
{
    public class SalesDWContext : DbContext
    {
        public SalesDWContext(DbContextOptions<SalesDWContext> options)
            : base(options)
        {
        }

        public DbSet<TotalSalesByYear> TotalSalesByYear { get; set; }
        public DbSet<TopProduct> TopProducts { get; set; }
        public DbSet<SalesByTerritory> SalesByTerritory { get; set; }
        public DbSet<PurchasingByVendor> PurchasingByVendor { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<TotalSalesByYear>()
                .HasNoKey()
                .ToView("vw_TotalSalesByYear", "dbo");

            modelBuilder.Entity<TopProduct>()
                .HasNoKey()
                .ToView("vw_TopProducts", "dbo");

            modelBuilder.Entity<SalesByTerritory>()
                .HasNoKey()
                .ToView("vw_SalesByTerritory", "dbo");

            modelBuilder.Entity<PurchasingByVendor>()
                .HasNoKey()
                .ToView("vw_PurchasingByVendor", "dbo");
        }
    }
}