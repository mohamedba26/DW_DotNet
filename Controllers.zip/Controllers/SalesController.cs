﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SalesDW.API.Data;

namespace SalesDW.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class SalesController : ControllerBase
    {
        private readonly SalesDWContext _context;

        public SalesController(SalesDWContext context)
        {
            _context = context;
        }

        [HttpGet("total-sales-by-year")]
        public async Task<IActionResult> GetTotalSalesByYear()
        {
            var data = await _context.TotalSalesByYear
                                     .AsNoTracking()
                                     .ToListAsync();
            return Ok(data);
        }

        [HttpGet("top-products")]
        public async Task<IActionResult> GetTopProducts()
        {
            var data = await _context.TopProducts
                                     .AsNoTracking()
                                     .ToListAsync();
            return Ok(data);
        }

        [HttpGet("sales-by-territory")]
        public async Task<IActionResult> GetSalesByTerritory()
        {
            var data = await _context.SalesByTerritory
                                     .AsNoTracking()
                                     .ToListAsync();
            return Ok(data);
        }
    }
}