﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SalesDW.API.Data;

namespace SalesDW.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class PurchasingController : ControllerBase
    {
        private readonly SalesDWContext _context;

        public PurchasingController(SalesDWContext context)
        {
            _context = context;
        }

        [HttpGet("purchasing-by-vendor")]
        public async Task<IActionResult> GetPurchasingByVendor()
        {
            var data = await _context.PurchasingByVendor
                                     .AsNoTracking()
                                     .ToListAsync();
            return Ok(data);
        }
    }
}